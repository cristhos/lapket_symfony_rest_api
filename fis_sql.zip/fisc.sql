-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Ven 30 Décembre 2016 à 13:04
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `fisc`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `code_cat` int(11) NOT NULL AUTO_INCREMENT,
  `nom_cat` varchar(50) NOT NULL,
  PRIMARY KEY (`code_cat`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` (`code_cat`, `nom_cat`) VALUES
(1, 'ENVIRONEMENT'),
(2, 'COMMMERCE EXTERIEUR'),
(3, 'FONDS DE PROMOTION CULTURELLE'),
(4, 'PREVOYANCE SOCIAL'),
(5, 'TRIBUNAL DE COMMERCE'),
(6, 'DIVISION DE L''INDUSTRIE'),
(7, 'INFRASTRUCTURE'),
(8, 'DIVISION DU TRAVAIL'),
(9, 'CDI'),
(10, 'INSS'),
(11, 'ONEM'),
(12, 'INPP');

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `code_client` int(11) NOT NULL AUTO_INCREMENT,
  `nom_client` varchar(50) NOT NULL,
  `adress_client` text NOT NULL,
  `email_client` varchar(50) NOT NULL,
  PRIMARY KEY (`code_client`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `evaluations`
--

CREATE TABLE IF NOT EXISTS `evaluations` (
  `code_evaluation` int(11) NOT NULL AUTO_INCREMENT,
  `code_client` int(11) NOT NULL,
  `code_taxe` int(11) NOT NULL,
  `montant` int(11) NOT NULL,
  `date_echeance` date NOT NULL,
  PRIMARY KEY (`code_evaluation`),
  KEY `code_client` (`code_client`),
  KEY `code_taxe` (`code_taxe`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `code_notification` int(11) NOT NULL AUTO_INCREMENT,
  `code_client` int(11) NOT NULL,
  `motif` varchar(20) NOT NULL,
  `statuts` varchar(30) NOT NULL,
  PRIMARY KEY (`code_notification`),
  KEY `code_client` (`code_client`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `taxes`
--

CREATE TABLE IF NOT EXISTS `taxes` (
  `code_taxe` int(11) NOT NULL AUTO_INCREMENT,
  `nom_taxe` varchar(50) NOT NULL,
  `code_cat` int(11) DEFAULT NULL,
  PRIMARY KEY (`code_taxe`),
  KEY `code_cat` (`code_cat`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Contenu de la table `taxes`
--

INSERT INTO `taxes` (`code_taxe`, `nom_taxe`, `code_cat`) VALUES
(1, 'POLLUTION', 1),
(2, 'T.RA', 1),
(3, 'ETUDE D''IMAPACT ENVIRONNEMENTAL', 1),
(4, 'ASSAINISSEMENT', 1),
(5, 'NUMERO IMPORT-EXPORT', 2),
(6, 'SIGNE GRAPHIQUE SUR LES VEHICULES ET AUTRES', 3),
(7, 'BILAN SOCIAL', 4),
(8, 'DECLARATION M.V.T', 4),
(9, 'VISAS AGO', 5),
(10, 'METROLOGIE LEGALE', 6),
(11, 'AGREMENT', 7),
(12, 'COMITE H''YGIENE', 8),
(13, 'DELEGATION SYNDICALE', 8),
(14, 'DECLARATION ANNUELLE DE LA MAIN D''OEUVRE', 8),
(15, 'IPR', 9),
(16, 'COTISATION MENSUELLE', 10),
(17, 'COTISATION MENSUELLE', 11),
(18, 'COTISATION MENSUELLE', 12);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `code_utilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `telephone` int(11) NOT NULL,
  `nom` varchar(40) NOT NULL,
  `postnom` varchar(40) NOT NULL,
  `prenom` varchar(40) NOT NULL,
  `role` varchar(40) NOT NULL,
  PRIMARY KEY (`code_utilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `evaluations`
--
ALTER TABLE `evaluations`
  ADD CONSTRAINT `evaluations_ibfk_1` FOREIGN KEY (`code_client`) REFERENCES `clients` (`code_client`),
  ADD CONSTRAINT `evaluations_ibfk_2` FOREIGN KEY (`code_taxe`) REFERENCES `taxes` (`code_taxe`);

--
-- Contraintes pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`code_client`) REFERENCES `clients` (`code_client`);

--
-- Contraintes pour la table `taxes`
--
ALTER TABLE `taxes`
  ADD CONSTRAINT `taxes_ibfk_1` FOREIGN KEY (`code_cat`) REFERENCES `categories` (`code_cat`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
